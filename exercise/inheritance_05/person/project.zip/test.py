from project.person import Person
from project.child import Child


ch = Child("ma",5)
print(ch)