from project.pokemon import Pokemon
from project.trainer import Trainer